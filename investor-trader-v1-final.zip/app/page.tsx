import Link from "next/link";
export default function Home() {
  return <main className="min-h-screen bg-white">
    <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
      <div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-violet-700 text-white font-black">I↔T</div><span className="font-extrabold text-violet-900">Investor ↔ Trader</span></div>
      <Link className="btn border border-violet-200 text-violet-800" href="/login">Log in</Link>
    </header>
    <section className="mx-auto grid max-w-6xl gap-10 px-5 py-20 md:grid-cols-2 md:items-center">
      <div><span className="badge bg-violet-50 text-violet-700">PRIVATE FINANCIAL RECORDS</span>
      <h1 className="mt-5 text-5xl font-black tracking-tight text-violet-950 md:text-6xl">Simple, clear records for investors and traders.</h1>
      <p className="mt-5 max-w-xl text-lg leading-8 text-slate-600">Track investments, agreed ROI, expected payouts, payments, confirmations and outstanding balances in one secure place.</p>
      <div className="mt-8 flex flex-wrap gap-3"><Link className="btn btn-primary" href="/register?role=investor">Join as Investor</Link><Link className="btn border border-violet-200 text-violet-800" href="/register?role=trader">Join as Trader</Link></div>
      </div>
      <div className="card p-6"><div className="rounded-2xl bg-violet-50 p-5"><p className="text-sm font-semibold text-violet-700">Example investment</p><div className="mt-4 grid gap-3 sm:grid-cols-2"><Metric label="Amount" value="₦500,000"/><Metric label="ROI" value="20%"/><Metric label="Expected profit" value="₦100,000"/><Metric label="Expected payout" value="₦600,000"/></div></div></div>
    </section>
  </main>
}
function Metric({label,value}:{label:string,value:string}){return <div className="rounded-xl bg-white p-4"><p className="text-xs text-slate-500">{label}</p><p className="mt-1 text-xl font-extrabold text-violet-950">{value}</p></div>}